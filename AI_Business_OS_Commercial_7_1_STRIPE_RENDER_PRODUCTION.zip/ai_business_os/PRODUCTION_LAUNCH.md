# AI Business OS 7.1 — Stripe + Render launch

## 1. Create Stripe products/prices
Create three recurring monthly prices in Stripe:
- Starter: $20/month
- Growth: $79/month
- Pro: $199/month
Copy the resulting `price_...` IDs.

## 2. Deploy to Render
Connect this project/repository to Render as a Node Web Service. Render can deploy web services from Git repositories and provides environment variables/secrets in the service Environment settings. The included `render.yaml` provisions the web service and PostgreSQL database.

Required environment variables:
- `APP_BASE_URL=https://YOUR-RENDER-DOMAIN`
- `STRIPE_SECRET_KEY=sk_live_...` (use `sk_test_...` during testing)
- `STRIPE_WEBHOOK_SECRET=whsec_...`
- `STRIPE_PRICE_STARTER=price_...`
- `STRIPE_PRICE_GROWTH=price_...`
- `STRIPE_PRICE_PRO=price_...`
- `DATABASE_URL` is supplied by Render from the Postgres service.

## 3. Configure Stripe webhook
In Stripe Dashboard, create a webhook endpoint:
`https://YOUR-RENDER-DOMAIN/api/billing/webhook`
Subscribe to:
- checkout.session.completed
- customer.subscription.created
- customer.subscription.updated
- customer.subscription.deleted
Copy the webhook signing secret into `STRIPE_WEBHOOK_SECRET`.

## 4. Test before going live
Use Stripe test mode first. Open `/`, choose Plans & Billing, enter a test email, and complete Checkout with Stripe's documented test payment method. Verify:
- Checkout redirects to Stripe
- successful payment returns to the app
- webhook delivery is successful
- subscription row is written to Postgres
- billing portal opens for the customer

## 5. Go live
Switch to live-mode Stripe keys and live Price IDs, update the webhook to the live endpoint, set `APP_BASE_URL` to the final HTTPS domain, redeploy, and perform one small real subscription test.

Never put Stripe secret keys in browser JavaScript or commit `.env` files.
