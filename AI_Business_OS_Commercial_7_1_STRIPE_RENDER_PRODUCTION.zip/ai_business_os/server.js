import express from 'express';
import helmet from 'helmet';
import compression from 'compression';
import Stripe from 'stripe';
import pg from 'pg';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express();
app.set('trust proxy',1);
app.use(helmet({contentSecurityPolicy:false}));
app.use(compression());

const stripeKey=process.env.STRIPE_SECRET_KEY;
const stripe=stripeKey?new Stripe(stripeKey):null;
const baseUrl=(process.env.APP_BASE_URL||'').replace(/\/$/,'');
const prices={starter:process.env.STRIPE_PRICE_STARTER,growth:process.env.STRIPE_PRICE_GROWTH,pro:process.env.STRIPE_PRICE_PRO};
const {Pool}=pg;
const pool=process.env.DATABASE_URL?new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.DATABASE_URL.includes('localhost')?false:{rejectUnauthorized:false}}):null;

async function initDb(){if(!pool)return;await pool.query(`create table if not exists subscriptions(id text primary key, customer_id text, status text, price_id text, plan text, email text, current_period_end timestamptz, updated_at timestamptz default now());`)}
function planForPrice(id){return Object.entries(prices).find(([,v])=>v&&v===id)?.[0]||null}
function requireStripe(req,res,next){if(!stripe)return res.status(503).json({error:'Billing is not configured yet.'});next()}

app.get('/health',(req,res)=>res.json({ok:true,service:'ai-business-os',billing:Boolean(stripe),database:Boolean(pool)}));
app.get('/api/billing/config',(req,res)=>res.json({plans:[{id:'starter',name:'Starter',price:20},{id:'growth',name:'Growth',price:79},{id:'pro',name:'Pro',price:199}]}));

// Stripe webhook must receive the raw request body before express.json().
app.post('/api/billing/webhook',express.raw({type:'application/json'}),async(req,res)=>{
  if(!stripe)return res.status(503).send('Billing not configured');
  let event;try{event=stripe.webhooks.constructEvent(req.body,req.headers['stripe-signature'],process.env.STRIPE_WEBHOOK_SECRET)}catch(e){return res.status(400).send(`Webhook Error: ${e.message}`)}
  try{
    if(['customer.subscription.created','customer.subscription.updated','customer.subscription.deleted'].includes(event.type)){
      const sub=event.data.object;const item=sub.items?.data?.[0];const priceId=item?.price?.id||null;const plan=planForPrice(priceId);
      if(pool) await pool.query(`insert into subscriptions(id,customer_id,status,price_id,plan,email,current_period_end,updated_at) values($1,$2,$3,$4,$5,$6,to_timestamp($7),now()) on conflict(id) do update set customer_id=excluded.customer_id,status=excluded.status,price_id=excluded.price_id,plan=excluded.plan,email=excluded.email,current_period_end=excluded.current_period_end,updated_at=now()`,[sub.id,String(sub.customer),sub.status,priceId,plan,sub.customer_email||null,sub.current_period_end||0]);
    }
    if(event.type==='checkout.session.completed'){
      const session=event.data.object;if(pool && session.subscription){const sub=await stripe.subscriptions.retrieve(session.subscription);const item=sub.items?.data?.[0];await pool.query(`insert into subscriptions(id,customer_id,status,price_id,plan,email,current_period_end,updated_at) values($1,$2,$3,$4,$5,$6,to_timestamp($7),now()) on conflict(id) do update set status=excluded.status,updated_at=now()`,[sub.id,String(sub.customer),sub.status,item?.price?.id||null,planForPrice(item?.price?.id),session.customer_details?.email||null,sub.current_period_end||0]);}}
    res.json({received:true});
  }catch(e){console.error(e);res.status(500).json({error:'Webhook processing failed'});}
});

app.use(express.json({limit:'100kb'}));
app.post('/api/billing/create-checkout-session',requireStripe,async(req,res)=>{
  try{
    const plan=String(req.body?.plan||'').toLowerCase();const email=String(req.body?.email||'').trim();
    if(!prices[plan])return res.status(400).json({error:'Unknown plan'});
    if(!email || !/^\S+@\S+\.\S+$/.test(email))return res.status(400).json({error:'Valid email required'});
    if(!baseUrl)return res.status(500).json({error:'APP_BASE_URL is not configured'});
    const session=await stripe.checkout.sessions.create({mode:'subscription',customer_email:email,line_items:[{price:prices[plan],quantity:1}],allow_promotion_codes:true,billing_address_collection:'auto',success_url:`${baseUrl}/?checkout=success&session_id={CHECKOUT_SESSION_ID}`,cancel_url:`${baseUrl}/?checkout=cancelled`,metadata:{plan},subscription_data:{metadata:{plan}}});
    res.json({url:session.url});
  }catch(e){console.error(e);res.status(500).json({error:e.message});}
});
app.post('/api/billing/portal',requireStripe,async(req,res)=>{
  try{const email=String(req.body?.email||'').trim();if(!email)return res.status(400).json({error:'Email required'});const customers=await stripe.customers.list({email,limit:1});if(!customers.data[0])return res.status(404).json({error:'No billing customer found for that email.'});if(!baseUrl)return res.status(500).json({error:'APP_BASE_URL is not configured'});const portal=await stripe.billingPortal.sessions.create({customer:customers.data[0].id,return_url:baseUrl});res.json({url:portal.url});}catch(e){res.status(500).json({error:e.message});}});

app.use(express.static(__dirname,{extensions:['html']}));
app.use((req,res)=>res.sendFile(path.join(__dirname,'index.html')));

const port=Number(process.env.PORT||10000);
initDb().then(()=>app.listen(port,'0.0.0.0',()=>console.log(`AI Business OS listening on ${port}`))).catch(e=>{console.error(e);process.exit(1)});
