# AI Business OS Commercial 7.1
Production SaaS starter for AI-powered business automation.

Features include dashboard, customers/leads, tasks, automations, AI assistant UI, marketing tools, PWA support, and Stripe subscription checkout.

## Plans
Starter $20/month • Growth $79/month • Pro $199/month

## Production
Run `npm ci` then `npm start`. Configure the variables listed in `PRODUCTION_LAUNCH.md`.
